<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "funciones.inc"?>
</head>
<body>
    <form action="EmpleadosDepartamento.php" method="post">
        <select name="Departamentos" id="Departamentos">
            <option value="-1">--Departamentos--</option>
            <?php
            foreach (f_todosDepartamentos() as $keydepartamento => $valordepartamento) { ?>
                <option value="<?php echo $keydepartamento ?>"><?php echo $valordepartamento["Nombre"] ?></option>
            <?php
            }
            ?>
        </select>
        <input type="submit"  value="Mostrar departamentos">
        </div>
    </form>
</body>
</html>