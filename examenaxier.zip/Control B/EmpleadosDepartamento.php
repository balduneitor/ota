<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "funciones.inc"?>
</head>
<body>
<table>
<?php

//var_dump (f_empleadosDepartamento([1]));  

$departamentos = $_POST["EmpleadosDepartamento.php"];

        ?>
        <tr>
            <th>Nombre empleado</th>
            <th>Puesto</th>
            <th>Fecha contratacion</th>
            <th>nombre sucursal</th>
            <th>Direccion sucursal</th>
            <th>Ciudad sucursal</th>
        </tr>
        
        <?php
            foreach (f_empleadosDepartamento($codDepartamento) as $keydepartamento => $valordepartamento) {
                if ($keydepartamento == $departamentos) {
                    foreach ($_POSTvalordepartamento["empleados"] as $keyempleados => $valorproductos) { ?>
                    <td id="<?php echo $keydepartamento ?>"><?php echo f_nombreApellidoEmpleado($codEmpleado)?></td>
                    <td id="<?php echo $keydepartamento ?>"><?php echo f_puestoEmpleado($codEmpleado) ?></td>
                    <td id="<?php echo $keydepartamento ?>"><?php echo f_fechaContratacionEmpleado($codEmpleado)?></td>
                    <td id="<?php echo $keydepartamento ?>"><?php echo f_nombreSucursal($codSucursal) ?></td>
                    <td id="<?php echo $keydepartamento ?>"><?php echo f_direccionSucursal($codSucursal)?></td>
                    <td id="<?php echo $keydepartamento ?>"><?php f_ciudadSucursal($codSucursal)?></td>

                        
                        </tr>
        <?php 
                    }
                }
            }
        ?>
        
       
    </table>
</body>
</html>